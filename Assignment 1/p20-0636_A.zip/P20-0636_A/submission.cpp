/*
ROLL # : P20-0636
NAME : Rao Muhammad Rafay
Assignment # 01
*/ 


#include <iostream>
using namespace std;

/*Returns the length of the string in number of characters. */
int Strlen(char *s1)
{
    // for counting the characters
    int cnt = 0;

    // iterating on all characters of s1
    while (true)
    {
        cnt++;
        s1++;
        int a = *s1;
        if (a == 0)
        {
            break;
        }
    }

    // returning length of string as int
    return cnt;
}

/*Copies string s2 into array s1. The value of s1 is returned. */
char *Strcpy(char *s1, const char *s2)
{
    // length of (s1)
    int lens1 = 0;
    for (int i = 0; s1[i] != '\0'; i++)
    {
        lens1++;
    }

    // length of (s2)
    int lens2 = 0;
    for (int i = 0; s2[i] != '\0'; i++)
    {
        lens2++;
    }

    // making a new pointer to a char array
    char *arr = new char[lens1 + lens2];

    // iterating and copying (s1) and (s2) to new char array (arr)
    for (int i = 0; s1[i] != '\0'; i++)
    {
        arr[i] = s1[i];
    }
    int i = 0;
    for (int j = lens1; j < lens1 + lens2; j++)
    {
        arr[j] = s2[i];
        i++;
    }

    // making (s1) equals to new array (arr)
    s1 = arr;

    return s1;
}

/*Compares the string s1 with the string s2.
The function returns 0 , less than 0 or greater
than 0 if s1 is equal to , less than or greater
than s2 , respectively. */
int StrCmp(const char *s1, const char *s2)
{
    // lenght of (s1)
    int lens1 = 0;
    for (int i = 0; s1[i] != '\0'; i++)
    {
        lens1++;
    }

    // lenght of (s2)
    int lens2 = 0;
    for (int i = 0; s2[i] != '\0'; i++)
    {
        lens2++;
    }

    // conditionnal statements for comparing lengths of s1 and s2
    if (lens1 == lens2)
    {
        return 0;
    }

    if (lens1 < lens2)
    {
        return -1;
    }

    // it will work as else condition (else not used to remove warning "function comes out of non void")
    return 1;
}

/*A call to StrTok breaks string s1 into
&quot;tokens&quot; ( logical pieces such as words
in a line of text) separated by character
contained in const char s2. size parameter
will be updated number of tokens and save
actual tokens in char**&amp; listOfTokens.
*/
void StrTok(char *s1, const char s2, char **&listOfTokens, int &size)
{
    // making a pointer to array
    char *arr[100] = {};

    // taking variables for the iteration algorithm
    int x = 0;
    int indi = 0;
    int indf = 0;
    int first = 0;
    for (int i = 0; s1[i] != '\0'; i++)
    {
        char temp[100];
        if (s1[i] == s2)
        {
            cout << i << endl;
            indf = i;
            for (int j = indi; j < indf; j++)
            {
                // appending characters of tokens in (temp)
                temp[j] = s1[j];
                first++;
                indi++;
            }

            if (first > 0)
            {
                for (int k = indi; k < indf; k++)
                {
                    temp[k] = s1[k];
                }
            }

            // appending (tokens) in (arr)
            arr[0] = temp;
            x++;
        }
    }
}

/*Searches the string s1 for the all the occurrences
of the string s2. Save starting indexes in array (listOfOccurrences).
And save updated size of array listOfOccurrences also return true. But
if s2 not found returns false. */
bool StrFind(char *s1, char *s2, int *&listOfOccurrences, int &size)
{
    // lenth of (s2)
    int lens2 = 0;
    for (int i = 0; s2[i] != '\0'; i++)
    {
        lens2++;
    }

    //  taking variable for iteration and making an array to store occurrences
    int ind = 0;
    int arrsizes[20];
    int indarr = 0;

    // iterating char array for checking the occurences
    for (int i = 0; s1[i] != '\0'; i++)
    {
        int chk = 0;
        if (s1[i] == s2[ind])
        {
            chk++;
            for (int j = 0; j < lens2 - 1; j++)
            {
                if (s1[i + 1 + j] == s2[ind + 1 + j])
                {
                    chk++;
                }
            }
        }

        // condition (if the char array is present)
        if (chk == lens2)
        {
            arrsizes[indarr] = i;
            indarr++;
            size++;
            return true;
        }
    }
    listOfOccurrences = arrsizes;

    // working as else condition
    return false;
}

/*swap the string of swapIndex0 and swapIndex1 within 2d char array s1 return true if indexes are correct and swapping is successful and return false if swapping is not successful (indexes are incorrect) */
bool StrSwapIn2DArray(char **s1, int numberOfRows, int swapIndex0, int swapIndex1)
{
}

int find(int array[], int length, int target)
{
    // initializing
    length += -1;

    if (length > -1) // as base condition
    {
        // condition for checking target
        if (array[length] == target)
        {
            // returning index if target found
            return length;
        }

        else
        {
            // recursive call to function
            find(array, length, target);
        }
    }

    // condition when target not found
    else
    {
        return -1;
    }
}

void replace(char *s1, char ch1, char ch2)
{
    // base condition for recursion
    if (*s1 == '\0')
    {
        return;
    }

    // condition for replacing the target character to desired character
    if (*s1 == ch1)
    {
        *s1 = ch2;
        // recursive call on rest of char array
        replace(s1 + 1, ch1, ch2);
    }

    // condition if target not found
    else
    {
        replace(s1 + 1, ch1, ch2);
    }
}

void PrintPattern1(int n, int k, char ch1, char ch2)
{
    // base condition
    if (k == 1)
    {
        return;
    }

    // as in question statement there's no restriction mentioned on using loops
    // and in c++ we can not print a character multiple times by multipilying a character to integer i.e in python "#"*2 == ##
    // so we are using iterations for purpose of printing character multiple times
    if (n > 0)
    {
        for (int i = n; i < k + 1; i++)
        {
            cout << i;
            for (int j = 0; j < i; j++)
            {
                cout << ch1;
            }
        }
    }

    cout << k - 1;
    for (int i = k - 1; i > 0; i--)
    {
        cout << ch2;
    }

    // recursive call to function
    PrintPattern1(n - k, k - 1, ch1, ch2);
}

void PrintPattern2(char ch, int n)
// NOTE:
// The prototype in this file (submission.cpp) was wrong as it was "void PrintPattern2(char ch, int n1, int n2)"
// I am CHANGING prototype as given in question file (Assignment.pdf)
{
    // base condition
    if (n == 0)
    {
        return;
    }

    // as in question statement there's no restriction mentioned on using loops
    // and in c++ we can not print a character multiple times by multipilying a character to integer i.e in python "#"*2 == ##
    // so we are using iterations for purpose of printing character multiple times
    int x = n - 1;
    for (int i = 0; i < x; i++)
    {
        cout << " ";
    }

    for (int j = 0; j < 5 - x; j++)
    {
        cout << ch;
    }

    cout << endl;

    // recursive call to the function
    PrintPattern2(ch, n - 1);
}
// this function is used in PrintPattern3 kindly uncomment it
/*
void printstarspace(int start, int unique, int st, int sp)
{
    int printsp = start - 2;

    if (printsp == 0)
    {
        int spdone = 0;
        for (int i = 0; i < st; i++)
        {
            cout << "*";

            if (spdone == 0)
            {
                for (int j = 0; j < sp; j++)
                {
                    cout << " ";
                }
                spdone++;
            }
        }
    }

    if (printsp != 0 && start - 2 < unique)
    {
        int spdone = 0;
        int stdone = 0;
        int spstart = 0;

        // starts and end spaces
        for (int i = 0; i < printsp + 1; i++)
        {
            cout << " ";
            spstart++;

            // stars
            if (stdone == 0 && spstart == printsp)
            {
                for (int j = 0; j < st; j++)
                {
                    cout << "*";
                    stdone++;

                    // spaces
                    if (spdone == 0)
                    {
                        for (int k = 0; k < 5 - (printsp * 2); k++) // 4 3 1 1 3 4
                        {
                            cout << " ";
                            spdone++;
                        }
                    }
                }
            }
        }
    }

    cout << endl;

    return;
}

*/
void PrintPattern3(int start, int end)
{
    int nolines = (end * 2) - 1;
    int unique = ((nolines - 1) / 2) + 1;

    // base condition
    if (start == nolines)
    {
        return;
    }
    
    if (start < unique)
    {
        // printstarspace(start + 1, unique, 2, nolines - 2);
        PrintPattern3(start + 1, end);
    }

    // unique condition
    if (start == unique)
    {
        // printstarspace(start + 1, unique, 1, nolines - 1);
        PrintPattern3(start + 1, end);
    }

    if (start > unique)
    {
        PrintPattern3(start + 1, end);
        // printstarspace(start + 1, unique, 2, nolines - 2);
    }
}